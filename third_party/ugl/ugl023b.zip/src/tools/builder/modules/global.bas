'$INCLUDE: 'global.bi'

