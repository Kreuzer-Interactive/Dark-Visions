'$INCLUDE: 'global.bi'

